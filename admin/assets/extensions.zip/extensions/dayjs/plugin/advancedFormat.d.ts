import { PluginFunc } from 'dayjs'

declare const plugin: PluginFunc
export = plugin
